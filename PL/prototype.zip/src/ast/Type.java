package ast;

public class Type extends Expr{

	public String nodeType() {
		return "type";
	}

}
