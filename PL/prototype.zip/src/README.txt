Run the code by running Main.java, in the default package.

There are a few examples .txt files in /Examples. test0 to test4 run successfully, test5 to test8 show syntax errors.

In Main.java, you can change "test0" to any other test (test0-8),
or you can go into the Examples folder and change the text files directly to run your own examples. 

We have implemented a lexer, parser, and interpreter for numbers, bools, if statements, while loops, variables, and strings. 

Note that the classes Tokenizer, Token, Node, LookAheadBuffer are from CS 2112 Critter world, albeit modified for our language.