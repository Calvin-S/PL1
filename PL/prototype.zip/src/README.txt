Run the code by running Main.java. We have implemented a simple lexer and parser on integers and booleans. One can change the .txt file or change the test file Main.java runs to test our code.

There are a few examples .txt files in /Examples. test to test3 runs successfully, test4 and test5 show syntax errors.
