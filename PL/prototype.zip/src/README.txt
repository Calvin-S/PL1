Run the code by running Main.java. We have implemented a simple lexer and parser on integers and booleans. One can change the .txt file or change the test file Main.java runs to test our code.

There are a few examples .txt files in /Examples. test0 to test3 runs successfully, test4 to test6 show syntax errors.

Note that the classes Tokenizer, Token, Node, LookAheadBuffer are from CS 2112 Critter world, albeit modified for our language.