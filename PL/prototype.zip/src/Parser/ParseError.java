package Parser;

@SuppressWarnings("serial")
public class ParseError extends Exception{
	public ParseError(String message) {
        super(message);
    }
}
