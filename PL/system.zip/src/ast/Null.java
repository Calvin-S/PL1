package ast;

public class Null extends Type{
	
}
