Run the code by running Main.java, in the default package.

There are a few example .txt files in /Examples. All of them run successfully.
In Main.java, you can change "test#" to any other file,
or you can go into the Examples folder and change the text files directly to run your own examples. 

If you wish to run one of the examples from the Demo, you can copy and paste the code into a text file
and change the Main.java code to open the corresponding file. 

The code cannot run multiple files at once. You must change the file name in Main.java manually. 